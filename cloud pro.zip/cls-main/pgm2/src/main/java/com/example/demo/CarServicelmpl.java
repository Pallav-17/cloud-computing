package com.example.demo;

import org.springframework.stereotype.Service; 
@Service 
public class CarServicelmpl implements CarService { 
@Override 
public void startCar() { 
// TODO Auto-generated method stub 
} 
public static void main(String[] args) { 
// TODO Auto-generated method stub 
System.out.println("Car is starting..."); 
} 
}