package com.example.prog6.demopgm5.studentdb;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.example.prog6.demopgm5.studentdbmodel.Student;
import com.example.prog6.demopgm5.studentdb.util.HibernateUtil;

public class App {
    public static void main(String[] args) {
        App app = new App();
        Student student = new Student();
        student.setId(1L); 
        student.setName("John "); 
        student.setAge(20);
        //app.saveStudent(student); 
        //app.updateStudent(student.getId(), "Jane ", 21); // Pass correct arguments 
        //app.getStudent(1L); 
        app.deleteStudent(2L); 
        }

    @SuppressWarnings("deprecation")
    public void saveStudent(Student student) {
        System.out.println("Attempting to save student...");
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            session.save(student);
            transaction.commit();
            System.out.println("Student saved successfully!");
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }

    @SuppressWarnings("deprecation")
    public void updateStudent(Long id, String name, int age) {
        System.out.println("Attempting to update student...");
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            Student student = session.get(Student.class, id);
            if (student != null) {
                student.setName(name);
                student.setAge(age);
                session.update(student);
                transaction.commit();
                System.out.println("Student updated successfully!");
            } else {
                System.out.println("Student not found with ID: " + id);
            }
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }

    public void getStudent(Long id) {
        System.out.println("Attempting to retrieve student...");
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            Student student = session.get(Student.class, id);
            if (student != null) {
                System.out.println("Student found: " + student.getName());
            } else {
                System.out.println("Student not found with ID: " + id);
            }
        } finally {
            session.close();
        }
    }

    @SuppressWarnings("deprecation")
    public void deleteStudent(Long id) {
        System.out.println("Attempting to delete student...");
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();
            Student student = session.get(Student.class, id);
            if (student != null) {
                session.delete(student);
                transaction.commit();
                System.out.println("Student deleted successfully!");
            } else {
                System.out.println("Student not found with ID: " + id);
            }
        } catch (Exception e) {
            if (transaction != null && transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null && session.isOpen()) {
                session.close();
            }
        }
    }
}
