package com.example.prog6.demopgm5.studentdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demopgm5StudentdbApplication {
    public static void main(String[] args) {
        SpringApplication.run(Demopgm5StudentdbApplication.class, args);
    }
}
