package com.example.prog5.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prog5Application {

	public static void main(String[] args) {
		SpringApplication.run(Prog5Application.class, args);
	}

}
