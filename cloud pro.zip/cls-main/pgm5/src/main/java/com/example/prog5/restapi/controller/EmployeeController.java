package com.example.prog5.restapi.controller;
import java.util.HashMap;
import java.util.List; import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity; import org.springframework.validation.BindingResult; import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping; import org.springframework.web.bind.annotation.PathVariable; import org.springframework.web.bind.annotation.PostMapping; import org.springframework.web.bind.annotation.PutMapping; import org.springframework.web.bind.annotation.RequestBody; import org.springframework.web.bind.annotation.RequestMapping; import org.springframework.web.bind.annotation.RestController;

import com.example.prog5.restapi.repository.EmployeeRepository;
import com.example.prog5.restapi.model.Employee;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employees") public class EmployeeController {

@Autowired
private EmployeeRepository employeeRepository;

@PostMapping
public ResponseEntity<?> createEmployee(@Valid @RequestBody Employee employee, BindingResult result) {
if (result.hasErrors()) {
Map<String, String> errors = new HashMap<>(); for (FieldError error : result.getFieldErrors()) {
 
errors.put(error.getField(), error.getDefaultMessage());
}
return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
}
Employee savedEmployee = employeeRepository.save(employee);
return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
}

@PutMapping("/{id}")
public ResponseEntity<?> updateEmployee(@PathVariable Long id, @Valid @RequestBody Employee employee, BindingResult result) {
if (result.hasErrors()) {
Map<String, String> errors = new HashMap<>(); for (FieldError error : result.getFieldErrors()) {
errors.put(error.getField(), error.getDefaultMessage());
}
return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
}
return employeeRepository.findById(id).map(existingEmployee -> { existingEmployee.setName(employee.getName());
existingEmployee.setAge(employee.getAge());
existingEmployee.setEmail(employee.getEmail());
Employee updatedEmployee = employeeRepository.save(existingEmployee);
return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);
}).orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
}

@GetMapping
public List<Employee> getAllEmployees() 
{ return employeeRepository.findAll();
}
}
