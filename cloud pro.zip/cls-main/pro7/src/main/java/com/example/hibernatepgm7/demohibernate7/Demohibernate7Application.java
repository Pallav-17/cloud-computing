package com.example.hibernatepgm7.demohibernate7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demohibernate7Application {
    public static void main(String[] args) {
        SpringApplication.run(Demohibernate7Application.class, args);
    }
}
