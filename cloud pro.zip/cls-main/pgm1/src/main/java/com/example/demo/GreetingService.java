package com.example.demo;


public interface GreetingService {
    String greet();
}