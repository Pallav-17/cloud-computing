package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class GreetingServicelmpl implements GreetingService {
    @Override
    public String greet() {
        return "Hello, World!";
    }
}